import { redirect } from "next/navigation";
import { isLocale, type Locale } from "@/lib/i18n";
import { getCurrentProfile } from "@/lib/supabase/server";
import { fetchDeals, fetchSwapOffers } from "@/lib/actions/transactions";
import { imageUrl } from "@/lib/data/listings";
import { DealsPanel } from "@/components/deals/DealsPanel";

export const dynamic = "force-dynamic";

export default async function DealsPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale: raw } = await params;
  const locale = (isLocale(raw) ? raw : "fr") as Locale;

  const profile = await getCurrentProfile();
  if (!profile) redirect(`/${locale}/login?next=/${locale}/deals`);

  const [deals, offers] = await Promise.all([fetchDeals(), fetchSwapOffers()]);

  const images = Object.fromEntries(deals.map((d) => [d.id, imageUrl(d.image_path)]));
  const offerImages = Object.fromEntries(
    offers.map((o) => [o.id, imageUrl(o.offered_image)]),
  );

  return (
    <DealsPanel deals={deals} offers={offers} images={images} offerImages={offerImages} />
  );
}
