import { NextResponse } from "next/server";
import { exchangeCodeForSession, verifyOtp } from "@/lib/supabase/auth";
import { writeSessionCookies } from "@/lib/supabase/session";
import { defaultLocale } from "@/lib/i18n/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Supabase e-posta bağlantılarının döndüğü nokta (doğrulama / şifre sıfırlama). */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const tokenHash = url.searchParams.get("token_hash");
  const code = url.searchParams.get("code");
  const type = (url.searchParams.get("type") ?? "signup") as
    | "signup"
    | "recovery"
    | "email_change"
    | "magiclink"
    | "invite";
  const nextParam = url.searchParams.get("next");
  const next = nextParam && nextParam.startsWith("/") ? nextParam : `/${defaultLocale}`;

  let tokens = null;

  if (tokenHash) {
    const { data } = await verifyOtp({ token_hash: tokenHash, type });
    tokens = data;
  } else if (code) {
    const { data } = await exchangeCodeForSession(code);
    tokens = data;
  }

  if (!tokens) {
    return NextResponse.redirect(new URL(`/${defaultLocale}/login?error=link`, url.origin));
  }

  await writeSessionCookies(tokens);
  return NextResponse.redirect(new URL(next, url.origin));
}
