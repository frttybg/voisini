import { headers } from "next/headers";
import { anonClient } from "@/lib/supabase/server";
import type { FieldErrors } from "@/lib/validation";

export type ActionState = {
  ok: boolean;
  message?: string;
  errors?: FieldErrors;
  redirect?: string;
  data?: Record<string, unknown>;
};

export const idleState: ActionState = { ok: false };

export async function clientIp(): Promise<string> {
  const h = await headers();
  return (
    h.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    h.get("x-real-ip") ??
    "unknown"
  );
}

/**
 * Sunucu tarafı hız sınırlama. Veritabanındaki check_rate_limit
 * fonksiyonunu kullanır; başarısız olursa isteği engellemez
 * (kullanılabilirlik > katı sınır), ama loglanır.
 */
export async function rateLimit(
  bucket: string,
  max: number,
  windowSeconds: number,
  extraKey?: string,
): Promise<boolean> {
  try {
    const ip = await clientIp();
    const client = anonClient();
    const { data, error } = await client.rpc<boolean>("check_rate_limit", {
      p_key: `${bucket}:${extraKey ?? ip}`,
      p_max: max,
      p_window_seconds: windowSeconds,
    });
    if (error) return true;
    return data !== false;
  } catch {
    return true;
  }
}

export function fail(message: string, errors?: FieldErrors): ActionState {
  return { ok: false, message, errors };
}

export function succeed(message?: string, extra?: Partial<ActionState>): ActionState {
  return { ok: true, message, ...extra };
}
