"use client";

import { useRouter } from "next/navigation";
import { useActionState, useState, useTransition } from "react";
import { useI18n } from "@/lib/i18n/provider";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { Modal, useToast } from "@/components/ui/Overlay";
import { Label, Select, Textarea } from "@/components/ui/Field";
import { startConversationAction } from "@/lib/actions/messages";
import { reportListingAction } from "@/lib/actions/listings";
import { idleState } from "@/lib/actions/shared";
import type { ListingType } from "@/lib/supabase/types";

export function ListingActions({
  listingId,
  type,
  isOwner,
  authenticated,
}: {
  listingId: string;
  type: ListingType;
  isOwner: boolean;
  authenticated: boolean;
}) {
  const { t, locale } = useI18n();
  const router = useRouter();
  const { toast } = useToast();
  const [pending, startTransition] = useTransition();
  const [reportOpen, setReportOpen] = useState(false);
  const [reportState, reportAction, reportPending] = useActionState(
    reportListingAction,
    idleState,
  );

  const primaryLabel =
    type === "sell"
      ? t.listing.buyNow
      : type === "rent"
        ? t.listing.rentNow
        : type === "swap"
          ? t.listing.makeOffer
          : type === "lend"
            ? t.listing.requestLoan
            : t.listing.contactSeller;

  function contact() {
    if (!authenticated) {
      router.push(`/${locale}/login?next=/${locale}/listings`);
      return;
    }
    startTransition(async () => {
      const result = await startConversationAction(listingId);
      if (!result.ok) {
        toast(t.common.error, "error");
        return;
      }
      router.push(`/${locale}/messages/${String(result.data?.conversationId ?? "")}`);
    });
  }

  async function share() {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ url });
        return;
      } catch {
        /* kullanıcı vazgeçti */
      }
    }
    await navigator.clipboard.writeText(url);
    toast(t.common.saved, "success");
  }

  if (isOwner) {
    return (
      <div className="flex flex-col gap-2">
        <Button href={`/${locale}/profile`} variant="outline" full icon="settings">
          {t.nav.myListings}
        </Button>
        <Button variant="ghost" full icon="share" onClick={share}>
          {t.listing.share}
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <Button size="lg" full icon="message" loading={pending} onClick={contact} magnetic>
        {primaryLabel}
      </Button>
      <div className="flex gap-2">
        <Button variant="outline" full icon="share" onClick={share}>
          {t.listing.share}
        </Button>
        <Button variant="ghost" icon="flag" onClick={() => setReportOpen(true)}>
          <span className="sr-only sm:not-sr-only">{t.listing.reportListing}</span>
        </Button>
      </div>

      <Modal open={reportOpen} onClose={() => setReportOpen(false)} title={t.listing.reportListing}>
        {reportState.ok ? (
          <p className="flex items-center gap-2 text-sm text-[var(--success)]">
            <Icon name="check" size={16} />
            {t.common.saved}
          </p>
        ) : (
          <form action={reportAction} className="flex flex-col gap-4">
            <input type="hidden" name="listingId" value={listingId} />
            <div>
              <Label htmlFor="reason" required>{t.listing.reportListing}</Label>
              <Select id="reason" name="reason" required>
                <option value="spam">Spam</option>
                <option value="scam">Fraude / arnaque</option>
                <option value="illegal">Contenu illégal</option>
                <option value="offensive">Contenu offensant</option>
                <option value="wrong_category">Mauvaise catégorie</option>
                <option value="other">{t.filters.all}</option>
              </Select>
            </div>
            <div>
              <Label htmlFor="details">{t.listing.description}</Label>
              <Textarea id="details" name="details" rows={4} maxLength={1000} />
            </div>
            <Button type="submit" full loading={reportPending}>
              {t.common.confirm}
            </Button>
          </form>
        )}
      </Modal>
    </div>
  );
}
